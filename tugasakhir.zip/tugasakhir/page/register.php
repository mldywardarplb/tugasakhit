<div class ="halaman">

 <link rel="stylesheet" href="css/register.css">



    <div class="container">
        <div class="login">
            <form method="post" action="page/proses_reg.php">
                <h1>Register</h1>
                <hr>
                <p>JavaCokeey</p>
                <label for="email">E-mail</label>
                <input type="email"name="email" placeholder="e-mail">
                <label for="username">Username</label>
                <input type="text" name="username" placeholder="username">
                <label for="password">Password</label>
                <input type="password" name="password" placeholder="Password">
                <button type="submit" name="register">Sign Up</button>
                <p>
                    <a href="login.php"></a>
                </p>
            </form>
        </div>
    </div>
</body>
</html>