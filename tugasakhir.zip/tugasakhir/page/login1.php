<div class="halaman">
    
<link rel="stylesheet" href="css/login.css">

<div class="container">
        <div class="login">
            <form action="proses_login.php" method="post" name="login">
                <h1>Login</h1>
                <hr>
                <p>JavaCokeey</p>
                <label for="">Username</label>
                <input type="text" name="username" placeholder="username">
                <label for="">Password</label>
                <input type="password" name="password" placeholder="Password">
                <button>Login</button>
            </form> 
        </div>
        <div class="right">
            <img src="image/login.jpg" alt="">
        </div>
    </div>
</div>
