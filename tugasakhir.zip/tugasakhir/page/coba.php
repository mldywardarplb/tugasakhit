<?php
include('koneksi.php');
$data=mysqli_query($koneksi,'select * from tb_resep');
echo '<pre>';
print_r($data);
echo '</pre>';
?>
<div class="halaman">

<link rel="stylesheet" href="../css/style.css">

<section class="home" id="home">

<div class="content">
    <h3>Javanese traditional Food Reciepe</h3>
    <span> Java Culinary </span>
    <p>Javanese Food have good taste, so let's cook javanese food!</p>
    <a href="#menu" class="btn">Menu</a>
</div>
</section>
<section class="menu" id="menu">

    <h1 class="heading"> Our Menu</h1>

    <div class="box-container">

    <?php
    while($resep =mysqli_fetch_array($data)) {
        ?>
        
        <div class="box">
            <img src="imagecrud/<?= $resep['gambar']?>" alt="" class="picture">
            <h3>
                <?= $resep['judul']?>
            </h3>
            <a href="resep.php?id_resep=<?=$resep['id']?>" class="botton">read more</a>
        </div>
        <?php
    }
    ?>
<!-- 
        <div class="box">
            <img src="image/sotoayamrill.jpg" alt="" class="picture">
            <h3>Soto Lamongan</h3>
            <a href="./sotoayam.php" class="botton">read more</a>
        </div>

        <div class="box">
            <img src="image/rawonrill.jpg" alt="" class="picture">
            <h3>Rawon</h3>
            <a href="./rawon.php" class="botton">read more</a>
        </div>

        <div class="box">
            <img src="image/nasgor.jpg" alt="" class="picture">
            <h3>Nasi Goreng Jawa</h3>
            <a href="./nasgor.php" class="botton">read more</a>
        </div>

        <div class="box">
            <img src="image/gethuk.jpg" alt="" class="picture">
            <h3>Gethuk</h3>
            <a href="./gethuk.php" class="botton">read more</a>
        </div>

        <div class="box">
            <img src="image/sate.jpg" alt="" class="picture">
            <h3>Sate Madura</h3>
            <a href="./sate.php" class="botton">read more</a>
        </div>

        <div class="box">
            <img src="image/klepon.jpg" alt="" class="picture">
            <h3>Klepon</h3>
            <a href="./klepon.php" class="botton">read more</a>
        </div>

        <div class="box">
            <img src="image/rujakcingur.jpg" alt="" class="picture">
            <h3>Rujak Cingur</h3>
            <a href="./rujakcingur.php" class="botton">read more</a>
        </div>

        <div class="box">
            <img src="image/bacem.jpg" alt="" class="picture">
            <h3>Baceman</h3>
            <a href="./bacem.php" class="botton">read more</a>
        </div> -->
    </div>
</section>

</div>
