<!DOCTYPE html>
<html lang="en">
    <head> 
         <title>tugas-akhir</title>
         <link rel="stylesheet" href="style.css? <?php echo time();?>">
</head>
<body>
            <nav class="nav">
            <h2 class="brand"><b>JavaCokeey.</b></h2>
            <ul>
                <li><a href="halaman1"><b>Home</b></a></li>
                <li><a href="halaman_addresep"><b>Add Reciepe</b></a></li>
                <li><a href="halaman_login"><b>Log in</b></a></li>
                <li><a href="halaman_logout"><b>Log Out</b></a></li>
</ul>
</nav>
<section class="home" id="halaman1">
    <div class="container-fluid">
<div class="content">
        <h3>Javanese Tradsional Food Recipe</h3>
        <span> nusantara culinary </span>
        <p>Javanese food have a good taste, so let's cooking javanese traditional food!</p>
        <a href="#" class="btn">shop now</a>
    </div>
</div>
</section>
</body>
</html>